## intent:greetings.hello
- hello
- hi
- hey buddy
- hi bru
- hello amigo
- hey hi
- hello there
- hello again
- hi, nice to see you again
