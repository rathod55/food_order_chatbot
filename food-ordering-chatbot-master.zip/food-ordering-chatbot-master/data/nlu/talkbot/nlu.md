## intent:confirm.affirm
- yes

## intent:confirm.deny
- no thank you

## intent:cuisine.type
- let's try some [north indian](cuisine:north indian)
- [idli sambar](food:idli sambar)

## intent:greetings.bye
- bye bye

## intent:greetings.hello
- hi

## intent:item.quantity
- [1](quant:1)

## intent:selected.item
- [chole ](food:chole) [chawal](food:chawal)
